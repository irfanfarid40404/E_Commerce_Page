function toggle1() {
    let blur = document.getElementById('blur');
    blur.classList.toggle('active');
    let popup = document.getElementById('popup');
    popup.classList.toggle('active');
    let image = document.getElementById('image');
    image.setAttribute('src', 'images/shoepop1.png');
}
function toggle2() {
    let blur = document.getElementById('blur');
    blur.classList.toggle('active');
    let popup = document.getElementById('popup');
    popup.classList.toggle('active');
    let image = document.getElementById('image');
    image.setAttribute('src', 'images/shoepop2.png');
}
function toggle3() {
    let blur = document.getElementById('blur');
    blur.classList.toggle('active');
    let popup = document.getElementById('popup');
    popup.classList.toggle('active');
    let image = document.getElementById('image');
    image.setAttribute('src', 'images/shoepop3.png');
}
function toggle4() {
    let blur = document.getElementById('blur');
    blur.classList.toggle('active');
    let popup = document.getElementById('popup');
    popup.classList.toggle('active');
    let image = document.getElementById('image');
    image.setAttribute('src', 'images/shoepop4.png');
}
function toggle5() {
    let blur = document.getElementById('blur');
    blur.classList.toggle('active');
    let popup = document.getElementById('popup');
    popup.classList.toggle('active');
    let image = document.getElementById('image');
    image.setAttribute('src', 'images/shoepop5.png');
}
function toggle6() {
    let blur = document.getElementById('blur');
    blur.classList.toggle('active');
    let popup = document.getElementById('popup');
    popup.classList.toggle('active');
    let image = document.getElementById('image');
    image.setAttribute('src', 'images/shoepop6.png');
}